******************************
GNU Free Documentation License
******************************

.. literalinclude:: _static/fdl.txt
