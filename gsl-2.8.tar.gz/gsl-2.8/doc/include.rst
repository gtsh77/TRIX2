.. |inlinefns| replace:: Inline versions of these functions are used when :code:`HAVE_INLINE` is defined.
.. |inlinefn| replace:: An inline version of this function is used when :code:`HAVE_INLINE` is defined.
.. |lapack| replace:: LAPACK
.. |octave| replace:: GNU octave
.. |fftpack| replace:: FFTPACK
.. |quadpack| replace:: QUADPACK
.. |minpack| replace:: MINPACK
.. |cquad| replace:: CQUAD
.. |blas| replace:: BLAS
.. |cblas| replace:: CBLAS
.. |atlas| replace:: ATLAS
.. |More| replace:: Moré

.. |newpage| raw:: latex

   \newpage
